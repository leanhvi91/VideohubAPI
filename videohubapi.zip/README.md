# VideohubAPI
This is collection of a serverless API using AWS lambda and APIGateway
